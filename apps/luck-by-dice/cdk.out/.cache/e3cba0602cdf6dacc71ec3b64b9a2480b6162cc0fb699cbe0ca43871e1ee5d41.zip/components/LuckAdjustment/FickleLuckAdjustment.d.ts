import { AbstractLuckAdjustment } from './AbstractLuckAdjustment';
export declare class FickleLuckAdjustment extends AbstractLuckAdjustment {
    adjustment(rollPercent?: number): number;
}
